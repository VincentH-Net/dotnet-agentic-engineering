# orleans

[![built with: dna](https://img.shields.io/badge/built%20with-dna-512BD4)](https://github.com/VincentH-Net/dotnet-agentic-engineering)

Parseable detector inputs; these projects are not built or restored.
