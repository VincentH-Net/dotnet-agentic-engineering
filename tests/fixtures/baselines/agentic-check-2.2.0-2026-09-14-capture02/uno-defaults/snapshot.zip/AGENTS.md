<!-- dotnet-agentic-engineering:dotnet-build-errors-and-warnings:start -->
## Configure and Fix .NET build errors and warnings

This directive does NOT govern WHEN to initiate a build, only WHAT to do before a build and when to repeat a build.

All `dotnet ...` commands MUST follow the separate "Running `dotnet ...`" directive.

1. Once per session, IMMEDIATELY BEFORE the first build, check if the current working folder
   contains an `.editorconfig` that contains the text
   `https://github.com/VincentH-Net/Modern.CSharp.Templates/blob/main/Editorconfig.md`.
   Do not count `.editorconfig` files inside `.git`, `.vs`, `bin`, `obj`, or `node_modules`.
   If NO, use the `dotnet-modern-csharp-editorconfig` skill EXACTLY as written to configure build errors and warnings in `.editorconfig` and MSBuild properties. Do NOT satisfy this check by manually adding the URL to an existing `.editorconfig`.

2. IMMEDIATELY AFTER building, IF any build errors or warnings are reported:

   1. IF there are multiple IDE formatting/style diagnostics that `dotnet format` can fix, run
      `dotnet format --include <files>` first IN THE FOREGROUND as described in the "Running `dotnet ...`" directive,
      ONLY including files that contain those diagnostics, to fix many diagnostics quickly. 
      Rebuild after formatting.

   2. Fix ALL remaining build errors and warnings by following these steps for each diagnostic:

      1. FIRST try HARD to fix the diagnostic by editing the code to comply with the rule that generated it.

      2. ONLY in RARE cases, where a fix would make the code much less readable AND the Microsoft Learn MCP or the
         https://learn.microsoft.com/ documentation of the error/warning describes a valid exclusion reason that
         CLEARLY applies in the context of the error/warning location, you can suppress diagnostics or warnings.
         If the Microsoft Learn MCP and https://learn.microsoft.com/ documentation are unavailable,
         do NOT suppress the diagnostic.
         When suppressing:
         - ALWAYS include the exclusion reason as rationale with the suppression
         - PREFER to do exclusions with the `[SuppressMessage]` attribute if possible; 
           IF the exclusion rationale applies to a whole project, add the attribute to a `GlobalSuppressions.cs`
           file (check for an existing file anywhere in the project, only create a new one if not found)

   3. Do not broaden the change beyond the files needed to fix the reported diagnostics,
      unless a wider mechanical format pass is explicitly required.
<!-- dotnet-agentic-engineering:dotnet-build-errors-and-warnings:end -->

<!-- dotnet-agentic-engineering:dotnet-cli-run:start -->
## Running `dotnet ...`

  All `dotnet ...` commands MUST be run directly in the foreground.

  Do NOT run `dotnet ...` commands in:
  - background terminals
  - persistent shell sessions
  - detached jobs
  - long-running interactive sessions

  Reason: background execution can hide immediate sandbox/access failures until a long timeout.

  If sandboxed access blocks the foreground command, rerun the same foreground command with the required escalation.
<!-- dotnet-agentic-engineering:dotnet-cli-run:end -->

<!-- dotnet-agentic-engineering:foundation-prompt-log:start -->
## Prompt Log

Prompt logs are stored in the git commit messages of the code commits they describe.

### Prompt Log Habit (MANDATORY for each agent-created code commit)

When creating a code commit, include a Prompt log block in that commit's initial commit message.
Report that the prompt log is included when committing, so the user can ask for a repair if needed.
Only include user prompts and agent questions + user answers since the previous Prompt log block 
(or session start if none yet). Omit continuation prompts. If the last prompt only asks to commit or
push the current work, omit that last prompt from the Prompt log. If there is no meaningful Prompt to
log, do not include a Prompt log block.

Commit format:

```text
original code commit subject

original code commit body

prompt-log:
"sanitized user prompt"

"sanitized next user prompt"

"Q: sanitized agent question -> A: sanitized user answer"
prompt-log-end:
```

Rules:

- Only include prompts/Q&A since the previous Prompt log block.
- Sanitized means redact secrets, tokens, credentials, private URLs, and personal data. 
  Keep all other text in user prompts, agent questions, and user answers VERBATIM - do NOT summarize. Encode each prompt or Q&A entry with the encoding script below for safety.
- For every user message since the previous Prompt log block:
  - If the user message answers an agent question, log it as:
    `"Q: sanitized agent question -> A: sanitized user answer"`
- Pre-commit self-check:
  - No prompt-log entry may be only a terse answer like `7`, `yes`, or `no` unless
    it was not answering an agent question.
  - If a user prompt is short or ambiguous, inspect the immediately preceding agent
    message and convert it to a Q&A entry when applicable.
- Preserve the original commit message verbatim before the Prompt log block.
- Keep `prompt-log-end:` immediately after the Prompt log entries, so tools can distinguish Prompt logs from later commit-message metadata such as Git trailers.
- The lines between `prompt-log:` and `prompt-log-end:` MUST be JSON string lines produced by the encoding script below, with blank separator lines between entries. Do not write raw prompt text directly in the commit message body and do not hand-escape JSON.

### Encoding Prompt Log Entries

Use this helper for every prompt or Q&A entry. It reads exactly one sanitized entry from standard input, writes each physical line as one JSON string line, and then writes one blank separator line.

```bash
prompt_log_entry() {
  perl -MJSON::PP=encode_json -0777 -we '
    my $text = do { local $/; <STDIN> };
    print encode_json($_), "\n" for split /\n/, $text, -1;
    print "\n";
  '
}

# examples
printf '%s' 'sanitized user prompt' | prompt_log_entry
printf '%s' 'Q: sanitized agent question -> A: sanitized user answer' | prompt_log_entry
```

### Retrieving Prompt Logs

When the user asks to show prompt logs, display the decoded prompt-log entries in full.
Do not abbreviate, summarize, replace text with `...`, or omit lines from any entry.
Preserve multiline entries and blank lines so the displayed text matches the decoded
prompt log content.

```bash
prompt_logs() {
  git log --reverse "$@" --format='%x00%H%x00%cI%x00%B' |
    perl -MJSON::PP=decode_json,encode_json -0777 -we '
      my $input = do { local $/; <STDIN> };
      my @fields = split /\0/, $input, -1;
      shift @fields while @fields && $fields[0] eq "";

      while (@fields >= 3) {
        my ($hash, $date, $body) = splice @fields, 0, 3;
        $hash =~ s/\A\n+//;
        $body =~ s/\n+\z//;

        next unless $hash =~ /\A[0-9a-f]{40}\z/;
        next unless $body =~ /^prompt-log:\n(.*?)^prompt-log-end:\n?/ms;

        print "$hash $date\n";
        my @entry_lines;
        for my $line (split /\n/, $1, -1) {
          if ($line =~ /\A[ \t]*\z/) {
            if (@entry_lines) {
              print encode_json(join "\n", @entry_lines), "\n";
              @entry_lines = ();
            }

            next;
          }

          my $text = decode_json($line);
          die "prompt-log entry line must be a JSON string\n" if ref $text;

          push @entry_lines, $text;
        }

        if (@entry_lines) {
          print encode_json(join "\n", @entry_lines), "\n";
        }

        print "\n";
      }
    '
}

# all prompt logs, showing only prompt log content
prompt_logs

# prompt logs since a date, showing only prompt log content
prompt_logs --since="2026-01-26"

# prompt logs in a date range, showing only prompt log content
prompt_logs --since="2026-01-26" --until="2026-02-07"
```
<!-- dotnet-agentic-engineering:foundation-prompt-log:end -->

<!-- dotnet-agentic-engineering:uno-build-and-run:start -->
## Build and Run
Build and run app via `uno_app_start` with the actual desktop target framework from the project file, for example `net10.0-desktop`, and `args: ["AGENT_CONSOLE_LOG=<path>"]`. 
The specified path is where the app's stdout and stderr output will be captured. You MUST specify this path, 
which MUST be within the `bin` folder of the app. The file MUST not exist yet and MUST be named 
with the current **local** time in ISO 8601 format: `app-stdout.YYYY-MM-DDTHHMMSS.log`. 
You MUST query the system clock for the actual current local time - do NOT estimate or hardcode it, and do NOT use UTC.

Do NOT run `dotnet build` prior to run the app - it would be redundant because `uno_app_start` already does a build.

### Verifying App Startup

- Use `uno_app_get_runtime_info` to check if the app is connected
- Call repeatedly until the app reports as connected - do NOT wait between repeats
- The specified log file must exist and must contain a log entry that mentions `uno-agentic-support`. If this is not true, first stop the app, then use the `uno-agentic-support` skill to fix logging, then start the app again and verify that the logging was fixed.
- If the Hot Design / Hot Reload UI is visible in the app, first stop the app, then use the `uno-agentic-support` skill to fix disabling Hot Design / Hot Reload UI, then start the app again and ensure that the Hot Design / Hot Reload UI is not visible.

### Stopping the App

- Use `uno_app_get_runtime_info` to get PID
- Use `uno_app_close` to terminate the app
<!-- dotnet-agentic-engineering:uno-build-and-run:end -->
