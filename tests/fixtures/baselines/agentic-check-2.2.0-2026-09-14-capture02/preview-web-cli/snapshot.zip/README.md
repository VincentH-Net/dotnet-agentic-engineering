# preview-web-cli

Parseable detector inputs; these projects are not built or restored.
