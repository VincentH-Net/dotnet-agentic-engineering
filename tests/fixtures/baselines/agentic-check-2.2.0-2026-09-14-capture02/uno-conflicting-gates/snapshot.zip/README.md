# uno-conflicting-gates

Parseable detector inputs; these projects are not built or restored.
