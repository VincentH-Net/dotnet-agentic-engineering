# uno-simple

Parseable detector inputs; these projects are not built or restored.
